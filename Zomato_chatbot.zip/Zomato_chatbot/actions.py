from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
from city_check import check_location
import json
import pandas as pd
from email_config import Config
from flask_mail_check import send_email

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'
		
	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"8fada28c8819b8cf217cd4b0fff1d349"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'american': 1,'chinese': 25, 'north indian': 50, 'italian': 55, 'mexican': 73, 'south indian': 85, 'thai': 95}
                
		global restaurant_df
		
		list1 = [0,20,40,60,80]
	        
		d = []
	        
		df = pd.DataFrame()
                
		for i in list1:
	        	
			results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), limit=i)
			
			d1 = json.loads(results)
			
			d = d1['restaurants']
			
			df1 = pd.DataFrame([{'restaurant_name': x['restaurant']['name'], 'restaurant_rating': x['restaurant']['user_rating']['aggregate_rating'],
				'restaurant_address': x['restaurant']['location']['address'],'budget_for2people': x['restaurant']['average_cost_for_two'],
				'restaurant_photo': x['restaurant']['featured_image'], 'restaurant_url': x['restaurant']['url'] } for x in d])
			
			df = df.append(df1)
		
		def budget_group(row):
			if row['budget_for2people'] <300 :
				return 'less'
			elif 300 <= row['budget_for2people'] <700 :
				return 'medium'
			else:
				return 'high'

		df.drop_duplicates(keep='first',inplace=True)

		df['budget'] = df.apply(lambda row: budget_group (row),axis=1)
		restaurant_df = df[(df.budget == price)]
		restaurant_df = restaurant_df.sort_values(['restaurant_rating'], ascending=0)
		
		top5 = restaurant_df.head(5)

		if len(top5)>0:
			response= 'Showing you top results:' + "\n"
			for index, row in top5.iterrows():
				response = response + str(row["restaurant_name"]) + ' (rated ' + row['restaurant_rating'] + ') in ' + row['restaurant_address'] + ' and the average budget for two people ' + str(row['budget_for2people'])+"\n"
		else:
			response = 'No restaurants found' 

		dispatcher.utter_message(str(response))

		return [SlotSet('location',loc)]

class Check_location(Action):
	def name(self):
		return 'action_check_location'
		
	def run(self, dispatcher, tracker, domain):
		loc = tracker.get_slot('location')
		check = check_location(loc)
		
		return [SlotSet('location',check['location_new']), SlotSet('location_found',check['location_f'])]

class SendMail(Action):
	def name(self):
		return 'email_restaurant_details'
		
	def run(self, dispatcher, tracker, domain):
		recipient = tracker.get_slot('email')

		top10 = restaurant_df.head(10)
		send_email(recipient, top10)

		dispatcher.utter_message("Have a good day!")
