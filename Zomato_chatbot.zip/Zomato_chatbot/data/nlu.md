## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- correct
- right, thank you
- um yes
- yes yes
- yea
- yes right
- oh yes
- yup
- yeah sure
- ya
- ye
- yes plz
- great choice
- yesyes
- yesss
- sounds really good
- thanks
- yes. please send it to [anirudhbkk@gmail.com](email)
- yeah. please send it to [xyz@sth.edu](email)
- cool. send all the restaurant details to [abc.2789@yahoo.co.in](email)
- [jskjsl_snbjs1883@hotmail.com](email)
- okay, send it to [sjaojosaj_2993.njskd@abc.com](email)
- can you please share the details on this id: [bdjnjnwsnak128_bcjd@ndjskk.com](email)
- yeah. cool. send it on [djjsq2_2o93o@abjdbjs.co.in](email)
- yes. please email all the details to this address: [anirudhbkk@gmail.com](email)
- [sunil.s.sarode@gmail.com](email)
- [ankit.a.009@gmail.com](email)
- sarode@un.org
- [sunil.s.sarode@gmail.com](email)

## intent:deny
- No, Thank you
- nops
- uh no
- nope
- never
- nah
- no no
- no thank you
- I'm good
- No
- no please
- not now
- later please
- dont want it
- do not send email
- no email

## intent:goodbye
- bye
- goodbye
- byee
- farewell
- cya
- k bye
- exit
- tc bye
- close
- good bye
- stop
- end
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- Hi
- are you there
- where are you
- ola
- help
- there?
- thr?
- Hieeeeeeeeeeeee
- Whats up?
- Hieee

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines](cuisine:chinese) restaurants in the [New Delhi](location:Delhi)
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese](cuisine:chinese)
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [rome](location) in a [moderate](price:mid) price range with [british](cuisine) food for [four](people:4) people
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- find me a restaurant
- [Italian](cuisine:italian)
- find me a restaurent
- saharanpur[](location:saharanpur)
- [high](price)
- [low](price)
- [medium](price)
- high[](price:high)
- medium[](price:medium)
- low[](price:low)
- find me a dinner place in [rishikesh](location)
- find me restaurants in [mumbai](location)
- iam hungry
- [chennai](location)
- [Mexican](cuisine:mexican)
- hi, find me a [chinese](cuisine) restaurant in [hyderabad](location)
- restarants
- [mumbai](location)
- restaurants
- [Chinese](cuisine:chinese)
- [medium](price)

## synonym:4
- four

## synonym:Delhi
- New Delhi

## synonym:bangalore
- Bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:italian
- Italian

## synonym:mexican
- Mexican

## synonym:mid
- moderate

## synonym:vegetarian
- veggie
- vegg

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}
