
def Config():
	gmail_user = 'sunil.rasa.case.study@gmail.com'
	gmail_pwd = 'Rasa@1234' 
	gmail_config = (gmail_user, gmail_pwd)
	return gmail_config